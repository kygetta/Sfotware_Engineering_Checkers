using System;
using System.Collections;
using System.Collections.Generic;
using TMPro; //added for text
using Unity.VisualScripting.Antlr3.Runtime.Tree;
using UnityEditor;
//using UnityEditor.Build;
using UnityEngine;
using UnityEngine.UI; //added for text
using static UnityEngine.UIElements.UxmlAttributeDescription;

/*
 * 
 * Attatch to circle prefabs
 * 
 * This script:
 * - keeps track of board
 * - lets players take turns moving circles
 *
 * 
 */

public class movePlayer : MonoBehaviour
{
    public static int[,] board = new int[8,8] { {0, 1, 0, 1, 0, 1, 0, 1}, 
                                                {1, 0, 1, 0, 1, 0, 1, 0},
                                                {0, 1, 0, 1, 0, 1, 0, 1}, 
                                                {0, 0, 0, 0, 0, 0, 0, 0}, 
                                                {0, 0, 0, 0, 0, 0, 0, 0},
                                                {-1, 0, -1, 0, -1, 0, -1, 0},
                                                {0, -1, 0, -1, 0, -1, 0, -1}, 
                                                {-1, 0, -1, 0, -1, 0, -1, 0} }; //layout of board (-1 = black circle, 0 = no circle, 1 = red circle)
                                                                                // (-2 if black king, 2 if red king)

    public static int[,] oldBoard = new int[8, 8]; //for UNDO option, stores board 1 step behind [NOTHING DONE WITH YET]

    double[,,] boardLocations = new double[8,8,2] {{{0, 0 }, {-2.5, 3.5}, {0, 0 }, {-.5, 3.5}, {0, 0 }, {1.5, 3.5}, {0, 0 }, {3.5, 3.5}},
                                                    {{-3.5, 2.5}, {0, 0 }, {-1.5, 2.5}, {0, 0 }, {.5, 2.5}, {0, 0 }, {2.5, 2.5}, {0, 0 }},
                                                    {{0, 0 }, {-2.5, 1.5}, {0, 0 }, {-.5, 1.5}, {0, 0 }, {1.5, 1.5}, {0, 0 }, {3.5, 1.5}},
                                                    {{-3.5, .5}, {0, 0 }, {-1.5, .5}, {0, 0 }, {.5, .5}, {0, 0 }, {2.5, .5}, {0, 0 }},
                                                    {{0, 0 }, {-2.5, -.5}, {0, 0 }, {-.5, -.5}, {0, 0 }, {1.5, -.5}, {0, 0 }, {3.5, -.5}},
                                                    {{-3.5, -1.5}, {0, 0 }, {-1.5, -1.5}, {0, 0 }, {.5, -1.5}, {0, 0 }, {2.5, -1.5}, {0, 0 }},
                                                    {{0, 0 }, {-2.5, -2.5}, {0, 0 }, {-.5, -2.5}, {0, 0 }, {1.5, -2.5}, {0, 0 }, {3.5, -2.5}},
                                                    {{-3.5, -3.5}, {0, 0 }, {-1.5, -3.5}, {0, 0 }, {.5, -3.5}, {0, 0 }, {2.5, -3.5}, {0, 0} }}; //positions of each grey square in board

    static bool blackTurn = true; //true if black player's turn
    static bool redTurn = false; //true if red player's turn    

    bool followMouse = false; //true if circle is following mouse    

    double[] currentLocation = new double[2]; //stores location of circle currently being focussed on
    int[] currentCoordinates = new int[2]; //stores coordinates of current circle in board array
    int[] moveToCoordinates = new int[2]; //stores location of potential spot to move to
    int[,] adjSpots = new int[3, 2]; //stores coordinates and true/falses from spotToGo method
    int[,] adjSpots2 = new int[3, 2]; //KING STUFF - stores coordinates and true/falses from spotToGo method for kings
    int[,] jumpSpots = new int[3, 2]; //stores coordinates and true/falses from jumpSpotToGo method
    int[,] jumpSpots2 = new int[3, 2]; //KING STUFF - stores extra coordinates and true/falses from jumpSpotToGo method for kings

    Vector2 destroyHere; //stores location of circle that needs to be destroyed

    public GameObject destroyer; //object to collide with circles and destroy them
    public GameObject starrer; //object to collide with circles and star them (used for UNDO)

    public createPrefabs cp; //GO used to access methods of other script

    bool isKing = false; //true if currently focussed on circle is a king

    public static bool justCaptured = false; //true if just captured a circle (used for UNDO - to make capture count correct)

    public GameObject star; //KING STUFF - GO used to hide and unhide star that marks circle as king


    // Start is called before the first frame update
    void Start()
    {
        destroyer = GameObject.Find("destroyer");
        starrer = GameObject.Find("starrer");
        cp = GameObject.FindObjectOfType(typeof(createPrefabs)) as createPrefabs; //attaches createPrefabs script to variable cp

        star.SetActive(false); //KING STUFF -- hides star that marks king on each circle

        copyBoard(); //sets oldBoard equal to what's in board
    }


    // Update is called once per frame
    void Update()
    {
        if (followMouse)
        {
            Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition); //gets & translates mouse position to world position
            transform.position = mousePosition; //position of object = where mouse is
        }
    }


    //Called whenever mouse clicked
    void OnMouseDown()
    {
        createPrefabs.message = ""; //clears message

        if (gameObject.name.Contains("blackCircle"))
        {
            justCaptured = false;
            createPrefabs.justUndid = false;

            if (blackTurn) //if circle should now follow mouse (if there is available spot)
            {              

                currentLocation[0] = transform.position.x;
                currentLocation[1] = transform.position.y; //stores location of clicked circle in currentLocation
                
                currentCoordinates = toWorldCoordinates(currentLocation); //stores boardLocation position of currentLocation coordinates

                //KING STUFF
                //isKing set to true if currentLocation circle is a king
                if (board[currentCoordinates[0], currentCoordinates[1]] == -2) isKing = true;
                else isKing = false;

                adjSpots = spotToGo(currentCoordinates, -1); //stores array from spotToGo
                if (isKing) adjSpots2 = spotToGo(currentCoordinates, 1); //KING STUFF - stores array from spotToGo of other direction for kings

                jumpSpots = jumpSpotToGo(currentCoordinates, board); //stores array from jumpSpotToGo
                if (isKing) jumpSpots2 = jumpSpotToGo(currentCoordinates, reverseBoard()); //KING STUFF - if king, jumpSpots2 stores array from jumpSpotToGo of reverse board


                copyBoard(); //sets oldBoard equal to what's in board pre-changes

                if (adjSpots[2, 0] == 1 || adjSpots[2, 1] == 1 || jumpSpots[2, 0] == 1 || jumpSpots[2, 1] == 1 //if there is a regular/jump spot for current selected piece to go
                    || (isKing && (adjSpots2[2, 0] == 1 || adjSpots2[2, 1] == 1 || jumpSpots2[2, 0] == 1 || jumpSpots2[2, 1] == 1))) //KING STUFF - OR if is king and there is regular spot or jump spot below to go
                {
                    board[currentCoordinates[0], currentCoordinates[1]] = 0; //adjusts board array to show this space is now empty

                    followMouse = true;
                    blackTurn = false;
                }
                else
                {
                    createPrefabs.message = "That piece cannot go anywhere! Pick a different one!";
                }
                
            }
            else if (redTurn)
            {
                createPrefabs.message = "It is " + createPrefabs.nameRedStore + "'s turn!";
            }
            else //if trying to put down the black circle
            {
                currentLocation[0] = transform.position.x;
                currentLocation[1] = transform.position.y; //stores location of clicked circle in currentLocation

                currentLocation = roundCoordinates(currentLocation); //Rounds coordinates to the nearest .5

                transform.position = new Vector2((float)currentLocation[0], (float)currentLocation[1]); //moves circle to rounded coordinates

                moveToCoordinates = toWorldCoordinates(currentLocation);//sets moveToCoordinates to clicked spot

                //checks if moveToCoordinates spot is okay spot to move to
                if (board[moveToCoordinates[0], moveToCoordinates[1]] == 0) //if spot is empty
                {
                   if ((moveToCoordinates[0] != 0 || moveToCoordinates[1] != 0) //if moveToCoordinates != {0, 0} 
                        && ((moveToCoordinates[0] == adjSpots[0, 0] && moveToCoordinates[1] == adjSpots[0, 1])
                        || (adjSpots[2, 0] == 1 && moveToCoordinates[0] == adjSpots[0, 0] && moveToCoordinates[1] == adjSpots[0, 1]) //if is in one of two above ajacent corner spots (and can go there)
                        || (adjSpots[2, 1] == 1 && moveToCoordinates[0] == adjSpots[1, 0] && moveToCoordinates[1] == adjSpots[1, 1])
                        || (jumpSpots[2, 0] == 1 && moveToCoordinates[0] == jumpSpots[0, 0] && moveToCoordinates[1] == jumpSpots[0, 1]) //or if in one of potential regular jump spots (and can go there)
                        || (jumpSpots[2, 1] == 1 && moveToCoordinates[0] == jumpSpots[1, 0] && moveToCoordinates[1] == jumpSpots[1, 1])
                        || (isKing && //KING STUFF - or if isKing AND
                           (adjSpots2[2, 0] == 1 && moveToCoordinates[0] == adjSpots2[0, 0] && moveToCoordinates[1] == adjSpots2[0, 1]) //if is in one of two below (king) ajacent corner spots (and can go there)
                        || (adjSpots2[2, 1] == 1 && moveToCoordinates[0] == adjSpots2[1, 0] && moveToCoordinates[1] == adjSpots2[1, 1])
                        || (jumpSpots2[2, 0] == 1 && moveToCoordinates[0] == jumpSpots2[0, 0] && moveToCoordinates[1] == jumpSpots2[0, 1])
                        || (jumpSpots2[2, 1] == 1 && moveToCoordinates[0] == jumpSpots2[1, 0] && moveToCoordinates[1] == jumpSpots2[1, 1])))) //or if in one of potential king jump spots
                   {

                        //currentCoordinates[0] = moveToCoordinates[0];
                        //currentCoordinates[1] = moveToCoordinates[1]; //change currentCoordinates to moveToCoordinates [POSSIBLY NOT NECESSARY?]

                        //KING STUFF
                        //Marks board spot as black king or regular black circle
                        if (isKing) //if already a king
                        {
                            board[moveToCoordinates[0], moveToCoordinates[1]] = -2; //marks new spot as having a black king circle
                        }
                        else if (moveToCoordinates[0] == 0) //if at the top of the board
                        {
                            board[moveToCoordinates[0], moveToCoordinates[1]] = -2; //marks new spot as having a black king circle

                            star.SetActive(true); //marks king with star
                        }
                        else
                        {
                            board[moveToCoordinates[0], moveToCoordinates[1]] = -1; //marks new board spot as having a regular black circle
                        }

                        redTurn = true;
                        createPrefabs.nameRed = "<mark=#FFFF00aa>" + createPrefabs.nameRedStore + "</mark>"; //highlights name of red player (the aa is for transparency)
                        createPrefabs.nameBlack = createPrefabs.nameBlackStore; //un-highlights name of black player

                        followMouse = false;

                        //if jumped, capture jumped circle
                        if (moveToCoordinates[0] == jumpSpots[0, 0] && moveToCoordinates[1] == jumpSpots[0, 1]) //and if in left jumped spot
                        {
                            goCapture(true, -1, false);
                        }
                        if (moveToCoordinates[0] == jumpSpots[1, 0] && moveToCoordinates[1] == jumpSpots[1, 1]) //if in right jumped spot
                        {                            
                            goCapture(false, -1, false);

                        }
                        if (isKing) //KING STUFF -- if is king and jumped backwards
                        {
                            if (moveToCoordinates[0] == jumpSpots2[0, 0] && moveToCoordinates[1] == jumpSpots2[0, 1]) //and if in left jumped spot
                            {
                                goCapture(true, -1, true);
                            }
                            if (moveToCoordinates[0] == jumpSpots2[1, 0] && moveToCoordinates[1] == jumpSpots2[1, 1]) //if in right jumped spot
                            {
                                goCapture(false, -1, true);

                            }
                        }

                   }
                   else
                   {
                        createPrefabs.message = "You can't move there!";
                   } 
                }
                else
                {
                    createPrefabs.message = "There's something in that spot!";
                }
            }
        }
        else if (gameObject.name.Contains("redCircle"))
        {
            justCaptured = false;
            createPrefabs.justUndid = false;

            if (redTurn)
            {
                currentLocation[0] = transform.position.x;
                currentLocation[1] = transform.position.y; //stores location of clicked circle in currentLocation

                currentCoordinates = toWorldCoordinates(currentLocation); //stores boardLocation position of currentLocation coordinates

                //KING STUFF
                //isKing set to true if currentCoordinates circle is a king
                if (board[currentCoordinates[0], currentCoordinates[1]] == 2) isKing = true;
                else isKing = false;

                adjSpots = spotToGo(currentCoordinates, 1); //stores array from spotToGo
                if(isKing) adjSpots2 = spotToGo(currentCoordinates, -1); //KING STUFF - stores array from spotToGo of other direction for kings

                jumpSpots = jumpSpotToGo(currentCoordinates, board); //stores array from jumpSpotToGo
                if (isKing) jumpSpots2 = jumpSpotToGo(currentCoordinates, reverseBoard()); //KING STUFF - if king, jumpSpots2 stores array from jumpSpotToGo of reverse board


                copyBoard(); //sets oldBoard equal to what's in board pre-changes

                if (adjSpots[2, 0] == 1 || adjSpots[2, 1] == 1 || jumpSpots[2, 0] == 1 || jumpSpots[2, 1] == 1 //if there is a spot for current selected piece to go
                    || (isKing && (adjSpots2[2, 0] == 1 || adjSpots2[2, 1] == 1 || jumpSpots2[2, 0] == 1 || jumpSpots2[2, 1] == 1)))
                {
                    board[currentCoordinates[0], currentCoordinates[1]] = 0; //adjusts board array to show this space is now empty

                    followMouse = true;
                    redTurn = false;
                } 
                else
                {
                    createPrefabs.message = "That piece cannot go anywhere! Pick a different one!";
                }
                
            }
            else if (blackTurn)
            {
                createPrefabs.message = "It is " + createPrefabs.nameBlackStore + "'s turn!";
            }
            else //if trying to put down the red circle
            {
                currentLocation[0] = transform.position.x;
                currentLocation[1] = transform.position.y; //stores location of clicked circle in currentLocation

                currentLocation = roundCoordinates(currentLocation); //Rounds coordinates to the nearest .5

                transform.position = new Vector2((float)currentLocation[0], (float)currentLocation[1]); //moves circle to rounded coordinates

                moveToCoordinates = toWorldCoordinates(currentLocation);//sets moveToCoordinates to clicked spot


                //checks if moveToCoordinates spot is okay spot to move to
                if (board[moveToCoordinates[0], moveToCoordinates[1]] == 0) //if spot is empty
                {                                       
                    if ((moveToCoordinates[0] != 0 || moveToCoordinates[1] != 0) //if moveToCoordinates != {0, 0}
                        && ((moveToCoordinates[0] == adjSpots[0, 0] && moveToCoordinates[1] == adjSpots[0, 1])
                        || (adjSpots[2, 0] == 1 && moveToCoordinates[0] == adjSpots[0, 0] && moveToCoordinates[1] == adjSpots[0, 1]) //if is in one of two below ajacent corner spots (and can go there)
                        || (adjSpots[2, 1] == 1 && moveToCoordinates[0] == adjSpots[1, 0] && moveToCoordinates[1] == adjSpots[1, 1])
                        || (jumpSpots[2, 0] == 1 && moveToCoordinates[0] == jumpSpots[0, 0] && moveToCoordinates[1] == jumpSpots[0, 1]) //or if in one of potential regular jump spots (and can go there)
                        || (jumpSpots[2, 1] == 1 && moveToCoordinates[0] == jumpSpots[1, 0] && moveToCoordinates[1] == jumpSpots[1, 1])
                        || (isKing && //KING STUFF - or if isKing AND
                           (adjSpots2[2, 0] == 1 && moveToCoordinates[0] == adjSpots2[0, 0] && moveToCoordinates[1] == adjSpots2[0, 1]) //if is in one of two above (king) ajacent corner spots (and can go there)
                        || (adjSpots2[2, 1] == 1 && moveToCoordinates[0] == adjSpots2[1, 0] && moveToCoordinates[1] == adjSpots2[1, 1])
                        || (jumpSpots2[2, 0] == 1 && moveToCoordinates[0] == jumpSpots2[0, 0] && moveToCoordinates[1] == jumpSpots2[0, 1])
                        || (jumpSpots2[2, 1] == 1 && moveToCoordinates[0] == jumpSpots2[1, 0] && moveToCoordinates[1] == jumpSpots2[1, 1])))) //or if in one of potential king jump spots
                    {

                        //currentCoordinates[0] = moveToCoordinates[0];
                        //currentCoordinates[1] = moveToCoordinates[1]; //change currentCoordinates to moveToCoordinates

                        //KING STUFF
                        //Marks board spot as red king or regular red circle
                        if (isKing) //if already a king
                        {
                            board[moveToCoordinates[0], moveToCoordinates[1]] = 2; //marks new spot as having a red king circle
                        }
                        else if (moveToCoordinates[0] == 7) //if at the bottom of the board
                        {
                            board[moveToCoordinates[0], moveToCoordinates[1]] = 2; //marks new spot as having a red king circle

                            star.SetActive(true); //marks king with star
                        }
                        else
                        {
                            board[moveToCoordinates[0], moveToCoordinates[1]] = 1; //marks new board spot as having a regular red circle
                        }

                        blackTurn = true;
                        createPrefabs.nameBlack = "<mark=#FFFF00aa>" + createPrefabs.nameBlackStore + "</mark>"; //highlights name of red player (the aa is for transparency)
                        createPrefabs.nameRed = createPrefabs.nameRedStore; //un-highlights name of black player

                        followMouse = false;

                        if (moveToCoordinates[0] == jumpSpots[0, 0] && moveToCoordinates[1] == jumpSpots[0, 1]) //and if in left jumped spot
                        {                            
                            goCapture(true, 1, false);
                        }
                        if (moveToCoordinates[0] == jumpSpots[1, 0] && moveToCoordinates[1] == jumpSpots[1, 1]) //if in right jumped spot
                        {                         
                            goCapture(false, 1, false);
                        }
                        if (isKing) //KING STUFF -- if is king and jumped backwards
                        {
                            if (moveToCoordinates[0] == jumpSpots2[0, 0] && moveToCoordinates[1] == jumpSpots2[0, 1]) //and if in left jumped spot
                            {
                                goCapture(true, 1, true);
                            }
                            if (moveToCoordinates[0] == jumpSpots2[1, 0] && moveToCoordinates[1] == jumpSpots2[1, 1]) //if in right jumped spot
                            {
                                goCapture(false, 1, true);

                            }
                        }

                    }
                    else
                    {
                        createPrefabs.message = "You can't move there!";
                    }
                }
                else
                {
                    createPrefabs.message = "There's something in that spot!";
                }
            }
        }
    }

    
    //called when one object collides with another
    void OnCollisionEnter2D(Collision2D col)
    {
        //if collides with destroyer, destroy circle
        if (col.gameObject.name == "destroyer")
        {
            Destroy(gameObject);

            col.transform.position = new Vector2(-11, 0); //moves destroyer back off screen
        }

        //if collides with starrer, mark circle with star (used for UNDO)
        if(col.gameObject.name == "starrer")
        {
            star.SetActive(true);

            col.transform.position = new Vector2(-11, -1); //moves starrer back off screen
        }
        
    }


    //takes in array with 2 world coordinates and rounds them to nearest .5
    double[] roundCoordinates(double[] arr)
    {
        arr[0] *= 2;
        arr[0] = Math.Round(arr[0]) / 2;
        arr[1] *= 2;
        arr[1] = Math.Round(arr[1]) / 2;

        return arr;
    }    


    //takes in array of 2 world coordinates, returns array position coordinates in boardLocations
    int[] toWorldCoordinates(double[] arr)
    {
        int[] arrFin = new int[2];

        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (arr[0] == boardLocations[i, j, 0] && arr[1] == boardLocations[i, j, 1])
                {
                    arrFin[0] = i;
                    arrFin[1] = j;
                }
            }
        }

        return arrFin;
    }


    //takes in array of 2 board coordinates and color of coordinates spot (-1 if black, 1 if red)
    //returns 2d array of this format: finArr = { {row-coord, col1-coord}, {row-coord, col2-coord}, { 0/1, 0/1 } };
    ///////////The 0s and 1s in the array represent true/false values (0 on left if left cannot be jump spot, etc.)
    public int[,] spotToGo(int[] boardLoc, int color)
    {
        int[,] finArr = new int[3, 2];// { {0, 0}, {0, 0}, {0, 0} };

        //getting rid of top & bottom outOfBounds errors
        if (boardLoc[0] + color >= 8 || boardLoc[0] + color < 0) //if potential board coordinates are too high or too low on board
        {
            return finArr; //returns array of all 0s
        }

        //int[,] adjacentSpots = new int[2, 2]; //stores 2 potential board coordinate spots to go (in coordinate form        
        if (boardLoc[1] - 1 >= 0) //if not at the left edge
        {
            finArr[0, 0] = boardLoc[0] + color; //forward coordinate
            finArr[0, 1] = boardLoc[1] - 1; //side coordinate
        } //else 1st coordinate = {0, 0}     
        if (boardLoc[1] + 1 < 8) //if not at the right edge
        {
            finArr[1, 0] = boardLoc[0] + color;
            finArr[1, 1] = boardLoc[1] + 1;
        }//else 2nd coordinate = {0, 0}

        if ((finArr[0, 0] != 0 || finArr[0, 1] != 0) && board[finArr[0, 0], finArr[0, 1]] == 0) //if left adjacent coordinate != {0, 0} AND its board spot = 0
        {
            finArr[2, 0] = 1; //set left marker to true
        }
        if ((finArr[1, 0] != 0 || finArr[1, 1] != 0) && board[finArr[1, 0], finArr[1, 1]] == 0) //if right adjacent coordinate != {0, 0} AND its board spot = 0
        {
            finArr[2, 1] = 1; //set right marker to true
        }

        return finArr;
    }


    //takes in array of 2 board coordinates and board array (reverse board for kings), checks if there is jumpable circle
    //returns 2d array of this format: finArr = { {row-coord, col1-coord}, {row-coord, col2-coord}, { 0/1, 0/1 } };
    ///////////The 0s and 1s in the array represent true/false values (0 on left if left cannot be jump spot, etc.)
    public int[,] jumpSpotToGo(int[] boardLoc, int[,] boardHere)
    {
        int[,] finArr = new int[3, 2];// { {0, 0}, {0, 0}, {0, 0} };

        int color = boardHere[boardLoc[0], boardLoc[1]]; //gets color of coordinates spot, -1 if black, 1 if red
        if (color % 2 == 0)
        {
            color = color / 2; //if marked as king (-2 or 2), changes to -1 or 1
        }

        //avoiding outOfBounds error
        if(color == -1 && boardLoc[0] <= 1) //if top of board is too close
        {
            return finArr; //return array full of 0s
        }
        if(color == 1 && boardLoc[0] >= 6) //if bottom of board is too close
        {
            return finArr; //return array full of 0s            
        }

        int[,] adjacentSpots = new int[2, 2]; //stores 2 adjacent coordinates/ spots where capturable circle might be
                                              //adjacentSpots = { {row-coord, col1-coord}, {row-coord, col2-coord} };
        adjacentSpots[0, 0] = boardLoc[0] + color;
        if (boardLoc[1] - 1 >= 0) //if not at the left edge
        {
            adjacentSpots[0, 1] = boardLoc[1] - 1;
        }
        else //if at the left edge
        {
            adjacentSpots[0, 1] = boardLoc[1] + 1; //makes it so 2 adjacentSpots coordinates are the same (since only 1 is applicable)
        }
        adjacentSpots[1, 0] = boardLoc[0] + color;
        if (boardLoc[1] + 1 < 8) //if not at the right edge
        {
            adjacentSpots[1, 1] = boardLoc[1] + 1;
        }
        else //if at the right edge
        {
            adjacentSpots[1, 1] = boardLoc[1] - 1; //makes it so 2 adjacentSpots coordinates are the same (since only 1 is applicable)
        }

        //MAYBE ONLY NEED ONE DOUBLE IF STATEMENT?
        if (boardHere[adjacentSpots[0, 0], adjacentSpots[0, 1]] == 0) //if left adjacent coordinate = 0 in board
        {
            finArr[2, 0] = 0; //set left marker to false

        }
        if (boardHere[adjacentSpots[1, 0], adjacentSpots[1, 1]] == 0) //if right adjacent coordinate = 0 in board
        {
            finArr[2, 1] = 0; //set right marker to false

            if (boardHere[adjacentSpots[0, 0], adjacentSpots[0, 1]] == 0) //if both adjacent coordinates = 0 in board
            {
                return finArr; //return array w/ both false and exit method

            }
        }


        int[,] adjAdjSpots = new int[2, 2]; //array to store coordinates of far left & right adjacent spots to the adjacent spots
                                            //                 [0, 0]       [0, 1]          [1, 0]      [1, 1]
                                            //adjAdjSpots = { {row coord, colLeft coord}, {row coord, colRight coord} };

        if(boardHere[adjacentSpots[0, 0], adjacentSpots[0, 1]] == -color //if left adjacent spot has other color in it (regular)
            || boardHere[adjacentSpots[0, 0], adjacentSpots[0, 1]] == -2*color) //if left adjacent spot has other color in it (king)
        {       

            //sets left coords in adjAdjSpots to  upper left spot of left adjacentSpots coords
            adjAdjSpots[0, 0] = adjacentSpots[0, 0] + color;
            if (adjacentSpots[0, 1] - 1 >= 0) //if not at the left edge
            {
                adjAdjSpots[0, 1] = adjacentSpots[0, 1] - 1;
            }
            else //if at the left edge
            {
                adjAdjSpots[0, 1] = adjacentSpots[1, 1] + 1; //makes it so 2 adjAdjSpots coordinates are the same (since only 1 is applicable)
            }

        }
        if(boardHere[adjacentSpots[1, 0], adjacentSpots[1, 1]] == -color //if right adjacent spot has other color in it (regular)
            || boardHere[adjacentSpots[1, 0], adjacentSpots[1, 1]] == -2*color) //if right adjacent spot has other color in it (king)
        {          

            //sets right coords in adjAdjSpots to upper right spot of left adjacentSpots coords
            adjAdjSpots[1, 0] = adjacentSpots[0, 0] + color;
            if (adjacentSpots[1, 1] + 1 < 8) //if not at the right edge
            {
                adjAdjSpots[1, 1] = adjacentSpots[1, 1] + 1;
            }
            else //if at the left edge
            {
                adjAdjSpots[1, 1] = adjacentSpots[0, 1] - 1; //makes it so 2 adjAdjSpots coordinates are the same (since only 1 is applicable)
            }
        }

        if (boardHere[adjAdjSpots[0, 0], adjAdjSpots[0, 1]] == 0 //if left adjAdjSpot is empty
            && (boardHere[adjacentSpots[0, 0], adjacentSpots[0, 1]] == -color //AND if left adjacentSpot has regular opposite color
            || boardHere[adjacentSpots[0, 0], adjacentSpots[0, 1]] == -2*color)) // or king opposite color
        {

            finArr[2, 0] = 1; //set left marker to true
            //set left coord values of finArr to left coord values of adjAdjSpots
            finArr[0, 0] = adjAdjSpots[0, 0];
            finArr[0, 1] = adjAdjSpots[0, 1];
        }
        if (boardHere[adjAdjSpots[1, 0], adjAdjSpots[1, 1]] == 0 //if right adjAdjSpot is empty
            && (boardHere[adjacentSpots[1, 0], adjacentSpots[1, 1]] == -color //AND if right adjacentSpot has regular opposite color
            || boardHere[adjacentSpots[1, 0], adjacentSpots[1, 1]] == -2*color)) // or king opposite color
        {
            finArr[2, 1] = 1; //set right marker to true
            //set right coord values of finArr to right coord values of adjAdjSpots
            finArr[1, 0] = adjAdjSpots[1, 0];
            finArr[1, 1] = adjAdjSpots[1, 1];
        }

        return finArr;
    }

 
    //KING STUFF
    //returns array with all the reverse values of the board (blacks where reds are, reds where blacks are)
    //used for king jumps
    int[,] reverseBoard()
    {
        int[,] finArr = new int[8, 8];

        for(int i = 0; i < 8; i++)
        {
            for(int j = 0; j < 8; j++)
            {
                finArr[i, j] = board[i, j] * -1;
            }
        }

        return finArr;
    }


    //captures circle, increments capture variable
    //checks to see if player has captured enough circles to win
    //takes in whether capturing to the left or right, int corresponding to color (-1 if black, 1 if red), and bool that's true if a king is trying to capture backwards
    void goCapture(bool left, int color, bool backwardsKing)
    {
        justCaptured = true;

        int side;
        if (left) side = -1;
        else side = 1;

        //increments captured count
        if (color == -1) createPrefabs.capturedBlack++;
        else createPrefabs.capturedRed++;

        if (backwardsKing) color = -color; //KING STUFF

        board[moveToCoordinates[0] - color, moveToCoordinates[1] - side] = 0; //mark spot of captured circle as empty

        destroyHere = new Vector2((float)boardLocations[moveToCoordinates[0] - color, moveToCoordinates[1] - side, 0], (float)boardLocations[moveToCoordinates[0] - color, moveToCoordinates[1] - side, 1]);
        destroyer.transform.position = destroyHere; //sends destroyer to position of captured circle
                       
        //checks if there is a winner yet
        if(createPrefabs.capturedRed >= 12) //if red won
        {            
            cp.someoneWon(1); //calls someoneWon method, passes in red
        }
        else if(createPrefabs.capturedBlack >= 12) //if black won
        {
            cp.someoneWon(-1); //calls someoneWon method, passes in black
        }

        if(createPrefabs.capturedRed == 11 && createPrefabs.capturedBlack == 11)
        {
            cp.someoneWon(0); //calls someoneWon method, marks as draw/tie
        }
    }


    //called by createPrefabs when reset button pressed
    //used to reset variables from this script
    public void OnReset()
    {
        redTurn = false;
        blackTurn = true;
    }

    
    //takes whatever is in board and puts it into oldBoard (used for UNDO)
    void copyBoard()
    {
        for(int i = 0; i < 8; i++)
        {
            for(int j = 0; j < 8; j++)
            {
                oldBoard[i, j] = board[i, j];
            }
        }
    }


    //takes whatever is in oldBoard and puts it into board (used for UNDO)
    public void reverseCopyBoard()
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                board[i, j] = oldBoard[i, j];
            }
        }
    }


    //takes in a vector2 coordinate and moves destroyer object to there (used for UNDO)
    public void destroyThat(Vector2 here)
    {
        destroyer.transform.position = here;
    }

    //GET AND SET METHODS
    //for accessing boardLocations from other script (used for UNDO)
    public double[,,] getBoardLocations()
    {
        return boardLocations;
    }
    //for accessing blackTurn variable from other script (used for UNDO)
    public bool getBlackTurn()
    {
        return blackTurn;
    }
    //for setting blackTurn variable from other script (used for UNDO)
    public void setBlackTurn(bool blackerTurn)
    {
        blackTurn = blackerTurn;
    }
    //for accessing redTurn variable from other script (used for UNDO)
    public bool getRedTurn()
    {
        return redTurn;
    }
    //for setting redTurn variable from other script (used for UNDO)
    public void setRedTurn(bool reddyTurn)
    {
        redTurn = reddyTurn;
    }


    //for changing visibity of king-marking stars from other script (used for UNDO)
    //parameter: vector2 of location of piece that should now have star
    public void showStar(Vector2 loc)
    {
        starrer.transform.position = loc;
    }


    //FOR TESTING -- prints board
   /* public void printBoard()
    {
        string printBoard = "board: ";
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                printBoard += board[i, j] + " ";
            }
            printBoard += "\n";
        }
        print(printBoard);
    } 


    //FOR TESTING -- prints any 2D array
    void printArr2D(int[,] arr)
    {
        string str = "array: ";
        for (int i = 0; i < arr.GetLength(0); i++)
        {
            for (int j = 0; j < arr.GetLength(1); j++)
            {
                str += arr[i, j] + " ";
            }
            str += "\n";
        }
        print(str);
    } */

}
