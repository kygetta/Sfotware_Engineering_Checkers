using System.Collections;
using System.Collections.Generic;
using TMPro; //added for text
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI; //added for text

/*
 * This script:
 * - gives user beginning text prompts
 * - displays all messages in messageTxt
 * - generates all circle prefabs and places them on board
 * 
 * 
 * Attach to any background object (NOT player pieces)
 *
 * */

public class createPrefabs : MonoBehaviour
{

    public static string nameBlack; //black/first player name
    public static string nameBlackStore; //black/first player name sans highlight
    public static string nameRed; //red/second player name
    public static string nameRedStore; //red/second player name sans highlight

    public GameObject redPrefab; //object for generating red circles
    public GameObject blackPrefab; //object for generating black circles

    public TMP_Text messageTxt; //TO, displays other messages to user 
    public TMP_Text name1Txt; //text object (TO), displays player 1 (black) name
    public TMP_Text name2Txt; //TO, displays player 2 (red) name

    public TMP_Text inputTxt; //TO from first user input field
    public TMP_Text inputTxt2; //TO from second user input field

    public TMP_Text capturedRedTxt; //TO, displays capturedRed
    public TMP_Text capturedBlackTxt; //TO, displays capturedBlack
    public static int capturedRed = 0; //number of circles captured by red
    public static int capturedBlack = 0; //number of circles captured by black

    int buttonCount = 0; //counts the # of times button pressed

    public GameObject inputField; //for hiding input field
    public GameObject inputField2;
    public GameObject button; //for hiding first "done" button

    public GameObject background; //for hiding background
    public GameObject square1; //for hiding squares

    public static string message = ""; //message that goes in messageTxt

    public static int scoreRed = 0; //number of games red player has won
    public static int scoreBlack = 0; //number of games black player has won    
    public TMP_Text scoreRedTxt; //TO, displays scoreRed
    public TMP_Text scoreBlackTxt; //TO, displays scoreBlack

    public TMP_Text buttonTxt; //TO, text on button

    public TMP_Text winnerTxt; //TO, for displaying winner

    bool filePressed = false; //true if dropdown buttons from "file" button should be showing
    bool editPressed = false; //true if dropdown button from "edit" button should be showing

    public GameObject exitButton; //for hiding "exit" button
    public GameObject resetButton; //for hiding "reset" button
    public GameObject undoButton; //for hiding "undo" button

    int lastWon = 1; //keeps track of what color won last game for swaps

    public movePlayer mp; //GO used to access methods/variables of other script

    public static bool justUndid = false;

    // Start is called before the first frame update
    void Start()
    {
        message = "Player 1 [BLACK], please enter your name!";
        nameBlack = "Player 1";
        nameRed = "Player 2";

        winnerTxt.text = "";

        background.GetComponent<Renderer>().enabled = false; //hides background
        square1.SetActive(false); //hides squares
        inputField2.SetActive(false); //hides 2nd input field

        capturedBlack = 0;
        capturedRed = 0;

        exitButton.SetActive(false); //hides "exit" button
        resetButton.SetActive(false); //hides "reset" button
        undoButton.SetActive(false); //hides "undo" button

        //mp = GameObject.FindObjectOfType(typeof(movePlayer)) as movePlayer; //attaches movePlayer script to variable mp (MOVING TO DIFFERENT SPOT)
    }

    // Update is called once per frame
    void Update()
    {
        messageTxt.text = message;
        name1Txt.text = nameBlack;
        name2Txt.text = nameRed;
        capturedBlackTxt.text = "Captured: " + capturedBlack;
        capturedRedTxt.text = "Captured: " + capturedRed;   
    }


    //Called each time button is clicked
    public void OnButtonPress()
    {
        buttonCount++;

        if(buttonCount == 1)
        {
            nameBlackStore = inputTxt.text; //gets name from user, stores in store variable
            nameBlack = nameBlackStore; //displays name
            message = "Player 2 [RED], please enter your name!";

            inputField.SetActive(false); //hides first input field
            inputField2.SetActive(true); //displays second input field

            buttonTxt.text = "Finished"; //changes text on button

        }
        else if(buttonCount == 2)
        {
            nameRedStore = inputTxt2.text; //gets another name from user
            nameRed = nameRedStore; //displays it
            messageTxt.text = "";

            //Generates all circle prefabs
            for (float i = 0f; i < 3; i++)
            {
                for (float j = 0f; j < 8; j += 2)
                {
                    float xPosBlack = j - 3.5f; //calculates x position red prefabs should generate to
                    if (i == 1) xPosBlack += 1; //makes position different for second row

                    float xPosRed = j - 2.5f; //calculates x position black prefabs should generate to
                    if (i == 1) xPosRed -= 1; //makes position different for second row

                    Instantiate(redPrefab, new Vector3(xPosRed, -i + 3.5f, 0), Quaternion.identity); //generates red circle
                    Instantiate(blackPrefab, new Vector3(xPosBlack, i - 3.5f, 0), Quaternion.identity); //generates black circle
                }
            }

            mp = GameObject.FindObjectOfType(typeof(movePlayer)) as movePlayer; //attaches mp to object attached to movePlayer (now that the circles exist)

            nameBlack = "<mark=#FFFF00aa>" + nameBlackStore + "</mark>"; //highlights name of black player (the aa is for transparency)

            inputField2.SetActive(false); //hides second input field
            button.SetActive(false); //hides button

            background.GetComponent<Renderer>().enabled = true; //un-hides background
            square1.SetActive(true); //un-hides squares

            message = "";

        }
    }

    
    //Called each time "file" button is pressed
    //Makes "exit" and "reset" buttons show up and disappear
    public void OnFilePress()
    {
        if (!filePressed) //if dropdown buttons are not showing
        {
            filePressed = true;
            exitButton.SetActive(true); //displays "exit" button
            resetButton.SetActive(true); //displays "reset" button
        }
        else //if need to hide dropdown buttons
        {
            filePressed = false;
            exitButton.SetActive(false); //hides "exit" button
            resetButton.SetActive(false); //hides "reset" button
        }
    }


    //Called each time "edit" button is pressed
    //Makes "undo" button appear and disappear
    public void OnEditPress()
    {
        if (!editPressed) //if dropdown button is not showing
        {
            editPressed = true;
            undoButton.SetActive(true); //displays "undo" button
        }
        else //if need to hide dropdown button
        {
            editPressed = false;
            undoButton.SetActive(false); //hides "undo" button
        }
    }


    //NOT TESTED (MIGHT ONLY WORK IN REGULAR GAME AND NOT IN WEIRD UNITY WINDOW)
    //Called each time "exit" button is pressed
    //Closes game
    public void OnExitPress()
    {
        Application.Quit();
    }


    //Called each time "reset" button is pressed
    public void OnResetPress()
    {
        //fills board array back with original layout
        int color;
        for (int i = 0; i < 8; i++)
        {
            if (i > 4) color = -1;
            else color = 1;

            for (int j = 0; j < 8; j++)
            {
                //puts the 1s and -1s in right places
                if ((i == 1 || i == 5 || i == 7) && (j % 2 == 0))
                {
                    movePlayer.board[i, j] = color;
                }
                else if ((i == 0 || i == 2 || i == 6) && (j % 2 == 1))
                {
                    movePlayer.board[i, j] = color;
                }
                //fills the rest with 0s
                else
                {
                    movePlayer.board[i, j] = 0;
                }
            }
        }

        //destroys all circle prefabs
        GameObject[] deadCircles = GameObject.FindGameObjectsWithTag("circle"); //creates array of all objects with "circle" tag (all circles tagged with this)
        foreach (GameObject deadCircle in deadCircles) //goes through whole array
        {
            Destroy(deadCircle); //destroys all circles
        }

        //Generates all circle prefabs
        for (float i = 0f; i < 3; i++)
        {
            for (float j = 0f; j < 8; j += 2)
            {
                float xPosBlack = j - 3.5f; //calculates x position red prefabs should generate to
                if (i == 1) xPosBlack += 1; //makes position different for second row

                float xPosRed = j - 2.5f; //calculates x position black prefabs should generate to
                if (i == 1) xPosRed -= 1; //makes position different for second row

                Instantiate(redPrefab, new Vector3(xPosRed, -i + 3.5f, 0), Quaternion.identity); //generates red circle
                Instantiate(blackPrefab, new Vector3(xPosBlack, i - 3.5f, 0), Quaternion.identity); //generates black circle
            }
        }

        //resets variables that need it
        capturedBlack = 0;
        capturedRed = 0;

        //swaps players if black won last
        if(lastWon == -1)
        {
            //swaps scores
            int temp = scoreBlack;
            scoreBlack = scoreRed;
            scoreRed = temp;

            //swaps names
            string temp2 = nameBlackStore;
            nameBlackStore = nameRedStore;
            nameRedStore = temp2;
        }

        //displays names with highlights correctly
        nameRed = nameRedStore;
        nameBlack = "<mark=#FFFF00aa>" + nameBlackStore + "</mark>";
        
        mp.OnReset(); //calls movePlayer method that resets more variables [DOES NOT WORK - NULLREFERENCE]

        winnerTxt.text = "";
    }


    //Called each time "undo" button is pressed
    public void OnUndoPress()
    {
        if (!justUndid)
        {
            double[,,] boardLocs = mp.getBoardLocations(); //stores array of potential positions on board (location of each grey square)

            //puts all the pieces in the right spots
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Vector2 pos = new Vector2((float)boardLocs[i, j, 0], (float)boardLocs[i, j, 1]); //stores location of this coordinate

                    if (movePlayer.board[i, j] != 0 && movePlayer.oldBoard[i, j] != movePlayer.board[i, j]) //if a non-empty spot should have something else or nothing in it
                    {
                        //Vector2 pos = new Vector2((float)boardLocs[i, j, 0], (float)boardLocs[i, j, 1]); //stores location of this coordinate
                        mp.destroyThat(pos); //calls method that sends destroyer to that location
                    }
                    if ((movePlayer.oldBoard[i, j] == 1 || movePlayer.oldBoard[i, j] == 2)
                        && movePlayer.board[i, j] != 1 && movePlayer.board[i, j] != 2) //if a spot that doesn't contain a red circle should have one
                    {
                        Instantiate(redPrefab, new Vector3((float)boardLocs[i, j, 0], (float)boardLocs[i, j, 1], 0), Quaternion.identity); //generates red circle
                        if (movePlayer.oldBoard[i, j] == 2) mp.showStar(pos); //if king, marks with star [NEED TO TEST]
                    }
                    if ((movePlayer.oldBoard[i, j] == -1 || movePlayer.oldBoard[i, j] == -2)
                        && movePlayer.board[i, j] != -1 && movePlayer.board[i, j] != -2) //if a spot that doesn't contain a black circle should have one
                    {
                        Instantiate(blackPrefab, new Vector3((float)boardLocs[i, j, 0], (float)boardLocs[i, j, 1], 0), Quaternion.identity); //generates red circle
                        if (movePlayer.oldBoard[i, j] == -2) mp.showStar(pos); //if king, marks with star [NEED TO TEST]
                    }
                }
            }

            //makes sure it's the correct person's turn
            if (mp.getRedTurn()) //if redTurn = true
            {
                mp.setRedTurn(false);
                nameRed = nameRedStore; //un-highlights name of red player
                mp.setBlackTurn(true);
                nameBlack = "<mark=#FFFF00aa>" + nameBlackStore + "</mark>"; //highlights name of black player

                if (movePlayer.justCaptured) capturedBlack--; //if undoing a capture, subtract from capture count [NOT WORKING]
            }
            else if (mp.getBlackTurn()) //if blackTurn = true
            {
                mp.setBlackTurn(false);
                nameBlack = nameBlackStore;
                mp.setRedTurn(true);
                nameRed = "<mark=#FFFF00aa>" + nameRedStore + "</mark>"; //highlights name of black player

                if (movePlayer.justCaptured) capturedRed--; //if undoing a capture, subtract from capture count [NOT WORKING]
            }

            mp.reverseCopyBoard(); //sets board equal to whatever is in oldBoard (both from movePlayer)

            justUndid = true;
        }        
    } 


    //EDITED BUT NOT TESTED
    //called if a player has won the game
    //parameters: int containing what color won (-1 if black, 1 if red, 0 if draw)
    public void someoneWon(int winner)
    {
        if(winner == 1) //if red won
        {
            winnerTxt.text = nameRedStore + " WINS!!!"; //display winner
            scoreRed++; //increment red score
            scoreRedTxt.text = "Score: " + scoreRed; //displays new red score            
            
        }
        else if(winner == -1) //if black won
        {
            winnerTxt.text = nameBlackStore + " WINS!!!"; //display winner
            scoreBlack++; //increment black score
            scoreBlackTxt.text = "Score: " + scoreBlack; //displays new black score

        }else if(winner == 0) //if it is a tie/draw
        {
            winnerTxt.text = "It is a TIE!!";
        }

        nameBlack = nameBlackStore; //un-highlights player black's name (if highlighted)
        nameRed = nameRedStore; //un-highlights player red's name (if highlighted)

        message = "Use the Menu to play again or quit!";

        lastWon = winner; //updates variable keeping track of who won last
    }
}
